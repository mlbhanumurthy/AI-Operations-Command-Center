import logging
from typing import List, Optional
from datetime import datetime
from google.oauth2.credentials import Credentials
from google_auth_oauthlib.flow import InstalledAppFlow
from google.auth.transport.requests import Request
from googleapiclient.discovery import build
import os.path
import pickle
from models import Signal
from config import settings

logger = logging.getLogger(__name__)

SCOPES = ['https://www.googleapis.com/auth/spreadsheets.readonly']


class SheetsMonitor:
    def __init__(self, spreadsheet_id: Optional[str] = None):
        self.service = None
        self.spreadsheet_id = spreadsheet_id
        self.last_row_count = 0
        
    def authenticate(self) -> bool:
        try:
            creds = None
            token_file = 'sheets_token.pickle'
            
            if os.path.exists(token_file):
                with open(token_file, 'rb') as token:
                    creds = pickle.load(token)
            
            if not creds or not creds.valid:
                if creds and creds.expired and creds.refresh_token:
                    creds.refresh(Request())
                elif settings.google_sheets_credentials_json and os.path.exists(settings.google_sheets_credentials_json):
                    flow = InstalledAppFlow.from_client_secrets_file(
                        settings.google_sheets_credentials_json, SCOPES)
                    creds = flow.run_local_server(port=0)
                else:
                    logger.warning("Google Sheets credentials not configured")
                    return False
                    
                with open(token_file, 'wb') as token:
                    pickle.dump(creds, token)
            
            self.service = build('sheets', 'v4', credentials=creds)
            return True
        except Exception as e:
            logger.error(f"Sheets authentication failed: {e}")
            return False
    
    def fetch_signals(self) -> List[Signal]:
        if not self.service or not self.spreadsheet_id:
            logger.warning("Sheets monitor not configured with spreadsheet ID")
            return []
        
        try:
            result = self.service.spreadsheets().values().get(
                spreadsheetId=self.spreadsheet_id,
                range='A:Z'
            ).execute()
            
            values = result.get('values', [])
            current_row_count = len(values)
            signals = []
            
            if current_row_count > self.last_row_count:
                new_rows = values[self.last_row_count:]
                
                for idx, row in enumerate(new_rows):
                    if not row:
                        continue
                        
                    signal = Signal(
                        id=f"sheets_{self.spreadsheet_id}_{self.last_row_count + idx}",
                        source="sheets",
                        timestamp=datetime.utcnow(),
                        content=f"New row: {' | '.join(str(cell) for cell in row)}",
                        metadata={
                            "row_index": self.last_row_count + idx,
                            "column_count": len(row)
                        },
                        raw_data={"row": row}
                    )
                    signals.append(signal)
                
                self.last_row_count = current_row_count
            
            logger.info(f"Fetched {len(signals)} signals from Google Sheets")
            return signals
            
        except Exception as e:
            logger.error(f"Error fetching Sheets signals: {e}")
            return []
