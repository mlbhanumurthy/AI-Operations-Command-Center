import logging
from typing import List, Optional
from datetime import datetime, timedelta
from slack_sdk import WebClient
from slack_sdk.errors import SlackApiError
from models import Signal
from config import settings

logger = logging.getLogger(__name__)


class SlackMonitor:
    def __init__(self):
        self.client = None
        self.last_check_time = datetime.utcnow() - timedelta(hours=1)
        
    def authenticate(self) -> bool:
        try:
            if not settings.slack_bot_token:
                logger.warning("Slack bot token not configured")
                return False
                
            self.client = WebClient(token=settings.slack_bot_token)
            self.client.auth_test()
            return True
        except SlackApiError as e:
            logger.error(f"Slack authentication failed: {e}")
            return False
    
    def fetch_signals(self) -> List[Signal]:
        if not self.client:
            if not self.authenticate():
                return []
        
        try:
            signals = []
            oldest_timestamp = str(int(self.last_check_time.timestamp()))
            
            conversations = self.client.conversations_list(
                types="public_channel,private_channel"
            )
            
            for channel in conversations.get('channels', [])[:10]:
                channel_id = channel['id']
                channel_name = channel['name']
                
                try:
                    history = self.client.conversations_history(
                        channel=channel_id,
                        oldest=oldest_timestamp,
                        limit=20
                    )
                    
                    for message in history.get('messages', []):
                        if message.get('type') == 'message' and 'text' in message:
                            signal = Signal(
                                id=f"slack_{channel_id}_{message.get('ts', '')}",
                                source="slack",
                                timestamp=datetime.utcnow(),
                                content=f"#{channel_name}: {message['text']}",
                                metadata={
                                    "channel": channel_name,
                                    "channel_id": channel_id,
                                    "user": message.get('user', ''),
                                    "ts": message.get('ts', '')
                                },
                                raw_data=message
                            )
                            signals.append(signal)
                except SlackApiError as e:
                    logger.warning(f"Error fetching messages from {channel_name}: {e}")
                    continue
            
            self.last_check_time = datetime.utcnow()
            logger.info(f"Fetched {len(signals)} signals from Slack")
            return signals
            
        except Exception as e:
            logger.error(f"Error fetching Slack signals: {e}")
            return []
