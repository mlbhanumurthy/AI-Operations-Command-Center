import logging
from typing import List, Optional
from datetime import datetime, timedelta
from google.oauth2.credentials import Credentials
from google_auth_oauthlib.flow import InstalledAppFlow
from google.auth.transport.requests import Request
from googleapiclient.discovery import build
import os.path
import pickle
from models import Signal
from config import settings

logger = logging.getLogger(__name__)

SCOPES = ['https://www.googleapis.com/auth/gmail.readonly']


class GmailMonitor:
    def __init__(self):
        self.service = None
        self.last_check_time = datetime.utcnow() - timedelta(hours=1)
        
    def authenticate(self) -> bool:
        try:
            creds = None
            if settings.gmail_token_json and os.path.exists(settings.gmail_token_json):
                with open(settings.gmail_token_json, 'rb') as token:
                    creds = pickle.load(token)
            
            if not creds or not creds.valid:
                if creds and creds.expired and creds.refresh_token:
                    creds.refresh(Request())
                elif settings.gmail_credentials_json and os.path.exists(settings.gmail_credentials_json):
                    flow = InstalledAppFlow.from_client_secrets_file(
                        settings.gmail_credentials_json, SCOPES)
                    creds = flow.run_local_server(port=0)
                else:
                    logger.warning("Gmail credentials not configured")
                    return False
                    
                if settings.gmail_token_json:
                    with open(settings.gmail_token_json, 'wb') as token:
                        pickle.dump(creds, token)
            
            self.service = build('gmail', 'v1', credentials=creds)
            return True
        except Exception as e:
            logger.error(f"Gmail authentication failed: {e}")
            return False
    
    def fetch_signals(self) -> List[Signal]:
        if not self.service:
            if not self.authenticate():
                return []
        
        try:
            query = f'after:{int(self.last_check_time.timestamp())}'
            results = self.service.users().messages().list(
                userId='me', q=query, maxResults=50).execute()
            
            messages = results.get('messages', [])
            signals = []
            
            for msg in messages:
                msg_data = self.service.users().messages().get(
                    userId='me', id=msg['id'], format='full').execute()
                
                headers = {h['name']: h['value'] 
                          for h in msg_data.get('payload', {}).get('headers', [])}
                
                snippet = msg_data.get('snippet', '')
                
                signal = Signal(
                    id=f"gmail_{msg['id']}",
                    source="gmail",
                    timestamp=datetime.utcnow(),
                    content=f"From: {headers.get('From', 'Unknown')}\nSubject: {headers.get('Subject', 'No Subject')}\n\n{snippet}",
                    metadata={
                        "from": headers.get('From', ''),
                        "subject": headers.get('Subject', ''),
                        "labels": msg_data.get('labelIds', [])
                    },
                    raw_data=msg_data
                )
                signals.append(signal)
            
            self.last_check_time = datetime.utcnow()
            logger.info(f"Fetched {len(signals)} signals from Gmail")
            return signals
            
        except Exception as e:
            logger.error(f"Error fetching Gmail signals: {e}")
            return []
