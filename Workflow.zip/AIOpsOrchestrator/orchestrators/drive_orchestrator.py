import logging
from typing import Dict, Any, Optional
from google.oauth2.credentials import Credentials
from google_auth_oauthlib.flow import InstalledAppFlow
from google.auth.transport.requests import Request
from googleapiclient.discovery import build
from googleapiclient.http import MediaFileUpload
import os.path
import pickle
from io import BytesIO
from models import OrchestrationAction, AnalyzedSignal
from config import settings
from datetime import datetime

logger = logging.getLogger(__name__)

SCOPES = ['https://www.googleapis.com/auth/drive.file']


class DriveOrchestrator:
    def __init__(self):
        self.service = None
        
    def authenticate(self) -> bool:
        try:
            creds = None
            token_file = 'drive_token.pickle'
            
            if os.path.exists(token_file):
                with open(token_file, 'rb') as token:
                    creds = pickle.load(token)
            
            if not creds or not creds.valid:
                if creds and creds.expired and creds.refresh_token:
                    creds.refresh(Request())
                elif settings.google_drive_credentials_json and os.path.exists(settings.google_drive_credentials_json):
                    flow = InstalledAppFlow.from_client_secrets_file(
                        settings.google_drive_credentials_json, SCOPES)
                    creds = flow.run_local_server(port=0)
                else:
                    logger.warning("Google Drive credentials not configured")
                    return False
                    
                with open(token_file, 'wb') as token:
                    pickle.dump(creds, token)
            
            self.service = build('drive', 'v3', credentials=creds)
            return True
        except Exception as e:
            logger.error(f"Drive authentication failed: {e}")
            return False
    
    def create_document(self, analyzed_signal: AnalyzedSignal, action_details: Dict[str, Any]) -> OrchestrationAction:
        action = OrchestrationAction(
            id=f"drive_{analyzed_signal.signal_id}_{datetime.utcnow().timestamp()}",
            signal_id=analyzed_signal.signal_id,
            action_type="drive_document",
            status="pending",
            platform="drive",
            details=action_details,
            created_at=datetime.utcnow()
        )
        
        if not self.service:
            if not self.authenticate():
                action.status = "failed"
                action.error = "Drive not configured"
                return action
        
        try:
            action.status = "in_progress"
            
            file_metadata = {
                'name': action_details.get('name', f"Signal_{analyzed_signal.signal_id}"),
                'mimeType': 'application/vnd.google-apps.document'
            }
            
            file = self.service.files().create(
                body=file_metadata,
                fields='id,webViewLink'
            ).execute()
            
            action.status = "completed"
            action.completed_at = datetime.utcnow()
            action.details["drive_file_id"] = file.get('id')
            action.details["web_link"] = file.get('webViewLink')
            logger.info(f"Created Drive document: {file.get('id')}")
            
        except Exception as e:
            action.status = "failed"
            action.error = str(e)
            logger.error(f"Error creating Drive document: {e}")
        
        return action
