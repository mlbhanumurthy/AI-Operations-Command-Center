import logging
from typing import Dict, Any, Optional
from trello import TrelloClient
from models import OrchestrationAction, AnalyzedSignal
from config import settings
from datetime import datetime

logger = logging.getLogger(__name__)


class TrelloOrchestrator:
    def __init__(self):
        self.client = None
        if settings.trello_api_key and settings.trello_token:
            try:
                self.client = TrelloClient(
                    api_key=settings.trello_api_key,
                    token=settings.trello_token
                )
            except Exception as e:
                logger.error(f"Error initializing Trello client: {e}")
    
    def create_card(self, analyzed_signal: AnalyzedSignal, action_details: Dict[str, Any]) -> OrchestrationAction:
        action = OrchestrationAction(
            id=f"trello_{analyzed_signal.signal_id}_{datetime.utcnow().timestamp()}",
            signal_id=analyzed_signal.signal_id,
            action_type="trello_card",
            status="pending",
            platform="trello",
            details=action_details,
            created_at=datetime.utcnow()
        )
        
        if not self.client or not settings.trello_board_id:
            action.status = "failed"
            action.error = "Trello not configured"
            logger.warning("Trello client not configured")
            return action
        
        try:
            action.status = "in_progress"
            
            board = self.client.get_board(settings.trello_board_id)
            lists = board.list_lists()
            
            target_list = lists[0] if lists else None
            if not target_list:
                raise Exception("No lists found in Trello board")
            
            card = target_list.add_card(
                name=action_details.get('name', analyzed_signal.summary),
                desc=action_details.get('description', analyzed_signal.reasoning)
            )
            
            action.status = "completed"
            action.completed_at = datetime.utcnow()
            action.details["trello_card_id"] = card.id
            logger.info(f"Created Trello card: {card.id}")
            
        except Exception as e:
            action.status = "failed"
            action.error = str(e)
            logger.error(f"Error creating Trello card: {e}")
        
        return action
