import logging
from typing import Dict, Any, Optional
from notion_client import Client
from models import OrchestrationAction, AnalyzedSignal
from config import settings
from datetime import datetime

logger = logging.getLogger(__name__)


class NotionOrchestrator:
    def __init__(self):
        self.client = None
        if settings.notion_api_key:
            self.client = Client(auth=settings.notion_api_key)
    
    def create_task(self, analyzed_signal: AnalyzedSignal, action_details: Dict[str, Any]) -> OrchestrationAction:
        action = OrchestrationAction(
            id=f"notion_{analyzed_signal.signal_id}_{datetime.utcnow().timestamp()}",
            signal_id=analyzed_signal.signal_id,
            action_type="notion_task",
            status="pending",
            platform="notion",
            details=action_details,
            created_at=datetime.utcnow()
        )
        
        if not self.client or not settings.notion_database_id:
            action.status = "failed"
            action.error = "Notion not configured"
            logger.warning("Notion client not configured")
            return action
        
        try:
            action.status = "in_progress"
            
            properties = {
                "Name": {
                    "title": [
                        {
                            "text": {
                                "content": action_details.get('title', analyzed_signal.summary)
                            }
                        }
                    ]
                }
            }
            
            if action_details.get('description'):
                children = [
                    {
                        "object": "block",
                        "type": "paragraph",
                        "paragraph": {
                            "rich_text": [
                                {
                                    "type": "text",
                                    "text": {
                                        "content": action_details['description']
                                    }
                                }
                            ]
                        }
                    }
                ]
            else:
                children = []
            
            response = self.client.pages.create(
                parent={"database_id": settings.notion_database_id},
                properties=properties,
                children=children
            )
            
            action.status = "completed"
            action.completed_at = datetime.utcnow()
            action.details["notion_page_id"] = response.get("id", "")
            logger.info(f"Created Notion task: {response.get('id', '')}")
            
        except Exception as e:
            action.status = "failed"
            action.error = str(e)
            logger.error(f"Error creating Notion task: {e}")
        
        return action
