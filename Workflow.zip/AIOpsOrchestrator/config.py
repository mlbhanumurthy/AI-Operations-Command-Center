from pydantic_settings import BaseSettings
from typing import Optional


class Settings(BaseSettings):
    openai_api_key: str = ""
    
    gmail_credentials_json: Optional[str] = None
    gmail_token_json: Optional[str] = None
    
    google_sheets_credentials_json: Optional[str] = None
    google_sheets_spreadsheet_id: Optional[str] = None
    google_drive_credentials_json: Optional[str] = None
    
    slack_bot_token: Optional[str] = None
    slack_app_token: Optional[str] = None
    
    notion_api_key: Optional[str] = None
    notion_database_id: Optional[str] = None
    
    trello_api_key: Optional[str] = None
    trello_api_secret: Optional[str] = None
    trello_token: Optional[str] = None
    trello_board_id: Optional[str] = None
    
    poll_interval_seconds: int = 300
    log_level: str = "INFO"
    
    class Config:
        env_file = ".env"
        env_file_encoding = "utf-8"


settings = Settings()
