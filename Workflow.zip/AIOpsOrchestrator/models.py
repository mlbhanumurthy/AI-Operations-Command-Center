from pydantic import BaseModel
from typing import Literal, Optional, Dict, Any, List
from datetime import datetime


class Signal(BaseModel):
    id: str
    source: Literal["gmail", "sheets", "slack"]
    timestamp: datetime
    content: str
    metadata: Dict[str, Any]
    raw_data: Optional[Dict[str, Any]] = None


class AnalyzedSignal(BaseModel):
    signal_id: str
    priority: Literal["critical", "high", "medium", "low"]
    urgency_score: float
    action_items: List[str]
    category: str
    summary: str
    reasoning: str
    suggested_actions: List[Dict[str, Any]]


class OrchestrationAction(BaseModel):
    id: str
    signal_id: str
    action_type: Literal["notion_task", "trello_card", "drive_document"]
    status: Literal["pending", "in_progress", "completed", "failed"]
    platform: str
    details: Dict[str, Any]
    created_at: datetime
    completed_at: Optional[datetime] = None
    error: Optional[str] = None


class MonitoringStatus(BaseModel):
    source: str
    last_check: datetime
    status: Literal["active", "error", "disabled"]
    signals_count: int
    error_message: Optional[str] = None
