import logging
from typing import List
from openai import OpenAI
from models import Signal, AnalyzedSignal
from config import settings
import json

logger = logging.getLogger(__name__)


class LLMReasoningEngine:
    def __init__(self):
        self.client = None
        if settings.openai_api_key:
            self.client = OpenAI(api_key=settings.openai_api_key)
    
    def analyze_signal(self, signal: Signal) -> AnalyzedSignal:
        if not self.client:
            logger.warning("OpenAI client not configured, using fallback analysis")
            return self._fallback_analysis(signal)
        
        try:
            prompt = f"""Analyze the following operational signal and provide a structured assessment:

Source: {signal.source}
Content: {signal.content}
Metadata: {json.dumps(signal.metadata, indent=2)}

Please analyze this signal and provide:
1. Priority level (critical/high/medium/low)
2. Urgency score (0-10)
3. List of action items
4. Category (e.g., incident, request, update, alert)
5. Brief summary
6. Reasoning for your assessment
7. Suggested automated actions (e.g., create Notion task, add Trello card, store in Drive)

Return your response as a JSON object with these keys:
{{
  "priority": "critical|high|medium|low",
  "urgency_score": 0-10,
  "action_items": ["item1", "item2"],
  "category": "category_name",
  "summary": "brief summary",
  "reasoning": "your reasoning",
  "suggested_actions": [
    {{"type": "notion_task", "title": "...", "description": "..."}},
    {{"type": "trello_card", "name": "...", "description": "..."}}
  ]
}}
"""
            
            response = self.client.chat.completions.create(
                model="gpt-4o-mini",
                messages=[
                    {"role": "system", "content": "You are an AI operations analyst that triages and prioritizes operational signals."},
                    {"role": "user", "content": prompt}
                ],
                temperature=0.3,
                response_format={"type": "json_object"}
            )
            
            analysis = json.loads(response.choices[0].message.content or "{}")
            
            return AnalyzedSignal(
                signal_id=signal.id,
                priority=analysis.get('priority', 'medium'),
                urgency_score=float(analysis.get('urgency_score', 5)),
                action_items=analysis.get('action_items', []),
                category=analysis.get('category', 'general'),
                summary=analysis.get('summary', signal.content[:100]),
                reasoning=analysis.get('reasoning', 'No reasoning provided'),
                suggested_actions=analysis.get('suggested_actions', [])
            )
            
        except Exception as e:
            logger.error(f"Error analyzing signal with LLM: {e}")
            return self._fallback_analysis(signal)
    
    def _fallback_analysis(self, signal: Signal) -> AnalyzedSignal:
        priority = "medium"
        urgency_score = 5.0
        
        content_lower = signal.content.lower()
        if any(word in content_lower for word in ['urgent', 'critical', 'emergency', 'asap']):
            priority = "critical"
            urgency_score = 9.0
        elif any(word in content_lower for word in ['important', 'high priority']):
            priority = "high"
            urgency_score = 7.0
        
        return AnalyzedSignal(
            signal_id=signal.id,
            priority=priority,
            urgency_score=urgency_score,
            action_items=[f"Review signal from {signal.source}"],
            category="unclassified",
            summary=signal.content[:100],
            reasoning="Fallback analysis (OpenAI not configured)",
            suggested_actions=[]
        )
    
    def batch_analyze(self, signals: List[Signal]) -> List[AnalyzedSignal]:
        return [self.analyze_signal(signal) for signal in signals]
