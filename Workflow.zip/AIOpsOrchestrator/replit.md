# AI Operations Command Center

## Overview
An intelligent operations monitoring system that watches Gmail, Google Sheets, and Slack for operational signals, uses LLM-powered reasoning to analyze and prioritize them, and automatically orchestrates tasks across Notion, Trello, and Google Drive.

## Architecture

### Core Components
1. **Monitoring Agents** (`monitors/`)
   - Gmail Monitor: Polls Gmail API for new emails
   - Sheets Monitor: Watches Google Sheets for new rows
   - Slack Monitor: Monitors Slack channels for messages

2. **LLM Reasoning Engine** (`reasoning_engine.py`)
   - Uses OpenAI GPT-4 to analyze signals
   - Classifies urgency and priority
   - Extracts action items and suggests orchestrations

3. **Orchestration Modules** (`orchestrators/`)
   - Notion: Creates tasks in Notion databases
   - Trello: Adds cards to Trello boards
   - Drive: Creates and organizes documents

4. **FastAPI Backend** (`main.py`)
   - REST API for dashboard
   - Real-time status monitoring
   - Manual trigger endpoint

5. **Web Dashboard** (`static/index.html`)
   - Real-time monitoring status
   - Signal visualization
   - Analyzed results display
   - Action audit trail

### Data Flow
1. Monitoring agents fetch signals from sources (Gmail/Sheets/Slack)
2. Signals stored in memory and sent to LLM reasoning engine
3. LLM analyzes, prioritizes, and suggests actions
4. Orchestration manager executes suggested actions
5. Dashboard displays all data in real-time

## Configuration

### Required API Keys
Set these in `.env` file (see `.env.example`):
- `OPENAI_API_KEY`: OpenAI API key for LLM reasoning
- Gmail, Sheets, Drive: OAuth credentials JSON files
- `SLACK_BOT_TOKEN`: Slack bot token
- `NOTION_API_KEY`: Notion integration token
- `TRELLO_API_KEY`, `TRELLO_TOKEN`: Trello credentials

### Monitoring Settings
- `POLL_INTERVAL_SECONDS`: How often to check sources (default: 300s)
- `LOG_LEVEL`: Logging verbosity (default: INFO)

## Setup Instructions

1. Copy `.env.example` to `.env`
2. Add your API keys and credentials
3. For Google APIs (Gmail, Sheets, Drive):
   - Download OAuth credentials from Google Cloud Console
   - Place JSON files in project root
   - First run will prompt for OAuth consent
4. Start the application: `python main.py`
5. Access dashboard at http://localhost:5000

## Technology Stack
- **Backend**: Python 3.11, FastAPI, uvicorn
- **Scheduling**: APScheduler for periodic monitoring
- **AI/LLM**: OpenAI GPT-4o-mini
- **APIs**: Google APIs, Slack SDK, Notion Client, py-trello
- **Storage**: In-memory (can be upgraded to PostgreSQL)
- **Frontend**: Vanilla JavaScript, HTML5, CSS3

## Recent Changes
- 2025-10-21: Initial project setup with full monitoring and orchestration capabilities

## User Preferences
- Preferred API key management: Manual configuration via environment variables
- No managed connectors used (user opted for manual setup)
