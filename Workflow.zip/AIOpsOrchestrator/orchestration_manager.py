import logging
from typing import List
from models import AnalyzedSignal, OrchestrationAction
from orchestrators import NotionOrchestrator, TrelloOrchestrator, DriveOrchestrator
from storage import storage

logger = logging.getLogger(__name__)


class OrchestrationManager:
    def __init__(self):
        self.notion = NotionOrchestrator()
        self.trello = TrelloOrchestrator()
        self.drive = DriveOrchestrator()
    
    def execute_actions(self, analyzed_signal: AnalyzedSignal) -> List[OrchestrationAction]:
        actions = []
        
        for suggested in analyzed_signal.suggested_actions:
            action_type = suggested.get('type')
            
            try:
                if action_type == 'notion_task':
                    action = self.notion.create_task(analyzed_signal, suggested)
                    actions.append(action)
                    storage.store_action(action)
                    
                elif action_type == 'trello_card':
                    action = self.trello.create_card(analyzed_signal, suggested)
                    actions.append(action)
                    storage.store_action(action)
                    
                elif action_type == 'drive_document':
                    action = self.drive.create_document(analyzed_signal, suggested)
                    actions.append(action)
                    storage.store_action(action)
                    
                else:
                    logger.warning(f"Unknown action type: {action_type}")
                    
            except Exception as e:
                logger.error(f"Error executing action {action_type}: {e}")
        
        if analyzed_signal.priority in ['critical', 'high'] and not actions:
            logger.info(f"High-priority signal {analyzed_signal.signal_id} with no automated actions")
        
        return actions
