import logging
from typing import List, Dict, Any, Literal, Optional
from datetime import datetime
from models import Signal, AnalyzedSignal, OrchestrationAction, MonitoringStatus
import json

logger = logging.getLogger(__name__)


class InMemoryStorage:
    def __init__(self):
        self.signals: List[Signal] = []
        self.analyzed_signals: List[AnalyzedSignal] = []
        self.actions: List[OrchestrationAction] = []
        self.monitoring_status: Dict[str, MonitoringStatus] = {}
        self.max_signals = 1000
    
    def store_signal(self, signal: Signal):
        self.signals.append(signal)
        if len(self.signals) > self.max_signals:
            self.signals = self.signals[-self.max_signals:]
        logger.debug(f"Stored signal: {signal.id}")
    
    def store_analyzed_signal(self, analyzed: AnalyzedSignal):
        self.analyzed_signals.append(analyzed)
        if len(self.analyzed_signals) > self.max_signals:
            self.analyzed_signals = self.analyzed_signals[-self.max_signals:]
        logger.debug(f"Stored analyzed signal: {analyzed.signal_id}")
    
    def store_action(self, action: OrchestrationAction):
        self.actions.append(action)
        logger.debug(f"Stored action: {action.id}")
    
    def update_monitoring_status(self, source: str, status: Literal["active", "error", "disabled"], signals_count: int = 0, error: Optional[str] = None):
        self.monitoring_status[source] = MonitoringStatus(
            source=source,
            last_check=datetime.utcnow(),
            status=status,
            signals_count=signals_count,
            error_message=error
        )
    
    def get_recent_signals(self, limit: int = 50) -> List[Signal]:
        return sorted(self.signals, key=lambda x: x.timestamp, reverse=True)[:limit]
    
    def get_recent_analyzed(self, limit: int = 50) -> List[AnalyzedSignal]:
        return sorted(self.analyzed_signals, key=lambda x: x.urgency_score, reverse=True)[:limit]
    
    def get_recent_actions(self, limit: int = 50) -> List[OrchestrationAction]:
        return sorted(self.actions, key=lambda x: x.created_at, reverse=True)[:limit]
    
    def get_monitoring_status(self) -> List[MonitoringStatus]:
        return list(self.monitoring_status.values())
    
    def get_stats(self) -> Dict[str, Any]:
        return {
            "total_signals": len(self.signals),
            "total_analyzed": len(self.analyzed_signals),
            "total_actions": len(self.actions),
            "actions_by_status": {
                "completed": len([a for a in self.actions if a.status == "completed"]),
                "failed": len([a for a in self.actions if a.status == "failed"]),
                "pending": len([a for a in self.actions if a.status == "pending"]),
                "in_progress": len([a for a in self.actions if a.status == "in_progress"])
            },
            "signals_by_source": {
                "gmail": len([s for s in self.signals if s.source == "gmail"]),
                "sheets": len([s for s in self.signals if s.source == "sheets"]),
                "slack": len([s for s in self.signals if s.source == "slack"])
            }
        }


storage = InMemoryStorage()
