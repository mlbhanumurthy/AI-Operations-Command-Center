import logging
from fastapi import FastAPI
from fastapi.staticfiles import StaticFiles
from fastapi.responses import HTMLResponse, FileResponse
from contextlib import asynccontextmanager
from monitoring_service import monitoring_service
from storage import storage
from config import settings

logging.basicConfig(
    level=getattr(logging, settings.log_level),
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)

logger = logging.getLogger(__name__)


@asynccontextmanager
async def lifespan(app: FastAPI):
    logger.info("Starting AI Operations Command Center")
    monitoring_service.start()
    yield
    logger.info("Shutting down AI Operations Command Center")
    monitoring_service.stop()


app = FastAPI(
    title="AI Operations Command Center",
    description="Monitor Gmail, Sheets, Slack for operational signals and auto-orchestrate tasks",
    version="1.0.0",
    lifespan=lifespan
)


@app.get("/")
async def root():
    with open("static/index.html", "r") as f:
        return HTMLResponse(content=f.read())


@app.get("/api/status")
async def get_status():
    return {
        "monitoring_status": [s.model_dump() for s in storage.get_monitoring_status()],
        "stats": storage.get_stats()
    }


@app.get("/api/signals")
async def get_signals(limit: int = 50):
    return {
        "signals": [s.model_dump() for s in storage.get_recent_signals(limit)]
    }


@app.get("/api/analyzed")
async def get_analyzed(limit: int = 50):
    return {
        "analyzed_signals": [a.model_dump() for a in storage.get_recent_analyzed(limit)]
    }


@app.get("/api/actions")
async def get_actions(limit: int = 50):
    return {
        "actions": [a.model_dump() for a in storage.get_recent_actions(limit)]
    }


@app.post("/api/check-now")
async def trigger_check():
    await monitoring_service.check_now()
    return {"status": "check initiated"}


app.mount("/static", StaticFiles(directory="static"), name="static")


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=5000)
