import logging
from apscheduler.schedulers.asyncio import AsyncIOScheduler
from apscheduler.triggers.interval import IntervalTrigger
from monitors import GmailMonitor, SheetsMonitor, SlackMonitor
from reasoning_engine import LLMReasoningEngine
from orchestration_manager import OrchestrationManager
from storage import storage
from config import settings

logger = logging.getLogger(__name__)


class MonitoringService:
    def __init__(self):
        self.scheduler = AsyncIOScheduler()
        self.gmail_monitor = GmailMonitor()
        self.sheets_monitor = SheetsMonitor(spreadsheet_id=settings.google_sheets_spreadsheet_id)
        self.slack_monitor = SlackMonitor()
        self.reasoning_engine = LLMReasoningEngine()
        self.orchestration_manager = OrchestrationManager()
        self.is_running = False
    
    def start(self):
        if self.is_running:
            logger.warning("Monitoring service already running")
            return
        
        logger.info(f"Starting monitoring service with {settings.poll_interval_seconds}s interval")
        
        self.scheduler.add_job(
            self.check_all_sources,
            trigger=IntervalTrigger(seconds=settings.poll_interval_seconds),
            id='monitor_all',
            name='Monitor all sources',
            replace_existing=True
        )
        
        self.scheduler.start()
        self.is_running = True
        logger.info("Monitoring service started")
    
    def stop(self):
        if not self.is_running:
            return
        
        self.scheduler.shutdown()
        self.is_running = False
        logger.info("Monitoring service stopped")
    
    async def check_all_sources(self):
        logger.info("Checking all monitoring sources...")
        
        await self._check_gmail()
        await self._check_sheets()
        await self._check_slack()
    
    async def _check_gmail(self):
        try:
            signals = self.gmail_monitor.fetch_signals()
            storage.update_monitoring_status('gmail', 'active', len(signals))
            
            for signal in signals:
                storage.store_signal(signal)
                analyzed = self.reasoning_engine.analyze_signal(signal)
                storage.store_analyzed_signal(analyzed)
                
                if analyzed.suggested_actions:
                    self.orchestration_manager.execute_actions(analyzed)
                    
        except Exception as e:
            logger.error(f"Error checking Gmail: {e}")
            storage.update_monitoring_status('gmail', 'error', 0, str(e))
    
    async def _check_sheets(self):
        try:
            signals = self.sheets_monitor.fetch_signals()
            storage.update_monitoring_status('sheets', 'active', len(signals))
            
            for signal in signals:
                storage.store_signal(signal)
                analyzed = self.reasoning_engine.analyze_signal(signal)
                storage.store_analyzed_signal(analyzed)
                
                if analyzed.suggested_actions:
                    self.orchestration_manager.execute_actions(analyzed)
                    
        except Exception as e:
            logger.error(f"Error checking Sheets: {e}")
            storage.update_monitoring_status('sheets', 'error', 0, str(e))
    
    async def _check_slack(self):
        try:
            signals = self.slack_monitor.fetch_signals()
            storage.update_monitoring_status('slack', 'active', len(signals))
            
            for signal in signals:
                storage.store_signal(signal)
                analyzed = self.reasoning_engine.analyze_signal(signal)
                storage.store_analyzed_signal(analyzed)
                
                if analyzed.suggested_actions:
                    self.orchestration_manager.execute_actions(analyzed)
                    
        except Exception as e:
            logger.error(f"Error checking Slack: {e}")
            storage.update_monitoring_status('slack', 'error', 0, str(e))
    
    async def check_now(self):
        await self.check_all_sources()


monitoring_service = MonitoringService()
